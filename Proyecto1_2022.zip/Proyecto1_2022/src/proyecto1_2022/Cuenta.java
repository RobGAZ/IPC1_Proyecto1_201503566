
package proyecto1_2022;

/**
 *
 * @author ROGA11
 */
public class Cuenta {
    int no_Cuenta;
    Cliente cliente;
    float saldo;
    
    public int getNumero(){
    return no_Cuenta;
    }
    public Cliente getCliente(){
    return cliente;
    }
    public float getSaldo(){
    return saldo;
    }
    
    public void setNumero(int numero_cuenta){
        no_Cuenta=numero_cuenta;
        
    }
    public void setCliente(Cliente Cliente){
        cliente=Cliente;
    }
    public void setSaldo(float Saldo){
        saldo=Saldo;
    }
    Cuenta(int numero_cuenta,Cliente Cliente,float Saldo){
        this.no_Cuenta=numero_cuenta;
        this.cliente=Cliente;
        this.saldo=Saldo;
    }

    @Override
    public String toString() {
        return "Cuenta{" + "no_Cuenta=" + no_Cuenta + ", cliente=" + cliente + ", saldo=" + saldo + '}';
    }
    
    
}
