package proyecto1_2022;

import javax.swing.JOptionPane;

public class Metodos {

    public static Admin Administrador = new Admin(1024, "Administrador", "password");
    public static Cliente Cliente[] = new Cliente[10];
    public static Cuenta Cuenta[] = new Cuenta[30];

    public static void crearUsuario(int i, int id, String nombre, String contraseña, String apellido) {

        Cliente[i] = new Cliente(id, nombre, contraseña, apellido);

        System.out.println(Cliente[i]);
        System.out.println(i);

    }

    public static int obtenerposicion() {
        int i;
        for (i = 0; i < Cliente.length; i++) {
            if (Cliente[i] == null) {
                break;
            }
        }
        return i;
    }

    public static boolean repetido(int id) {
        for (int i = 0; i < Cliente.length; i++) {
            while (Cliente[i] != null) {
                if (id == Cliente[i].getID()) {
                    return true;
                }
                break;
            }
        }
        return false;
    }

    public static boolean obtenerid(int id) {
        int i;
        for (i = 0; i < Cliente.length; i++) {
            while (Cliente[i] != null) {
                if (id == Cliente[i].getID()) {
                    return true;
                }
                break;
            }
        }
        return false;
    }

    public static boolean obtenerpass(String pass) {
        int i;
        for (i = 0; i < Cliente.length; i++) {
            while (Cliente[i] != null) {
                if (Cliente[i].getContra().equals(pass)) {
                    return true;
                }
                break;
            }
        }
        return false;

    }

    public static int obtenerindex() {
        int i;
        for (i = 0; i < Cuenta.length; i++) {
            if (Cuenta[i] == null) {
                break;
            }
        }
        return i;
    }

    public static Cliente cliente(int i) {

        return Cliente[i];
    }

    public static int indicecliente(int id) {
        int i;
        for (i = 0; i < Cliente.length; i++) {
            if (id == Cliente[i].getID()) {
                break;
            }
        }
        return i;
    }

    public static void crearCuenta(int i, int no, Cliente Cliente, float saldo) {

        Cuenta[i] = new Cuenta(no, Cliente, saldo);
        System.out.println(Cuenta[i]);
        System.out.println(i);
    }
    public static Cuenta cuenta(int i){
//        System.out.println(Cuenta[i].getCliente().getID());
        return Cuenta[i];
        
    }

    public static int obtenerposicioncuentas() {
        int i;
        for (i = 0; i < Cuenta.length; i++) {
            if (Cuenta[i] == null) {
                break;
            }
        }
        return i;
    }

    public static int contado(int id) {

        for (int i = 0; i < Cuenta.length; i++) {
            int a = 0;
            while (Cuenta != null && Cliente!=null) {
                if (id == Cuenta[i].getCliente().getID()) {
                    
                    return a++;
                }
                break;
            }
        }
        return 0;
    }
    public static int recorrer(){
        int i;
        for(i=0;i<Cuenta.length;i++){
        }
        return i;
    }

    
}
