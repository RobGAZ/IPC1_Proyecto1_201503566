
package proyecto1_2022;

/**
 *
 * @author ROGA11
 */
public class Cliente {
    int ID;
    String Nombre,Password,Apellido;
    
    public int getID(){
    return ID;
    }
    public String getNombre(){
    return Nombre;
    }
    public String getContra(){
    return Password;
    }
    public String getApellido(){
    return Apellido;
    }
    
    public void setID(int id){
        ID=id;
    }
    public void setNombre(String nombre){
        Nombre=nombre;
    }
    public void setContra(String contra){
        Password=contra;
    }
    public void setApellido(String apellido){
        Apellido=apellido;
    }
    
    public Cliente(int id,String nombre,String contra,String apellido){
        this.ID=id;
        this.Nombre=nombre;
        this.Password=contra;
        this.Apellido=apellido;
    }

    @Override
    public String toString() {
        return "Cliente{" + "ID=" + ID +'}';
    }
    
    
}
