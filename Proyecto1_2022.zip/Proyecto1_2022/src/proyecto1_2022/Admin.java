
package proyecto1_2022;


public class Admin {
    int ID;
    String Nombre,Password;
    
    public int getID(){
    return ID;
    }
    public String getNombre(){
    return Nombre;
    }
    public String getContra(){
    return Password;
    }
    
    public void setID(int id){
        ID=id;
    }
    public void setNombre(String nombre){
        Nombre=nombre;
    }
    public void setContra(String contra){
        Password=contra;
    }
    
    public Admin(int id,String nombre,String contra){
        this.ID=id;
        this.Nombre=nombre;
        this.Password=contra;
    }
    
}
