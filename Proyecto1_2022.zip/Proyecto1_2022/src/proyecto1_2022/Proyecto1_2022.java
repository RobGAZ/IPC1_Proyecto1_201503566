
package proyecto1_2022;

import Interfaz.Inicio;

public class Proyecto1_2022 {

   
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
       
    }
    
}
